

function validar(){
    window.open("../Index.html","self");
    
}
